import torch
import torch.nn as nn
from torch.nn import Sigmoid
from torch.nn import Module
from torch.optim import Adam
from torch.nn import BCELoss
import numpy as np
import matplotlib.pyplot as plt
from collections import defaultdict
from random import randrange
import random
import os
cwd=os.getcwd()
import scipy.io
from scipy.io import loadmat

from scipy.optimize import minimize

class Generator(nn.Module):
    def __init__(self):
        super(Generator, self).__init__()
        self.linear=nn.Sequential(
            nn.Linear(nz, ngf),
            nn.ReLU(True),
            )
        self.l1_up=nn.ConvTranspose2d(ngf, ngf, 4, 1, 0)
        
        #################################
        # 4 x 4
        #################################
        self.l4_1=nn.ConvTranspose2d(ngf, ngf//2, 3, 1, 1)
        
        self.l4_2=nn.ConvTranspose2d(ngf//2, ngf//2, 3, 1, 1)
        self.l4_batch_2=nn.BatchNorm2d(ngf//2)
        
        self.l4_3=nn.ConvTranspose2d(ngf//2, ngf//2, 3, 1, 1)
        self.l4_batch_3=nn.BatchNorm2d(ngf//2)
        
        self.l4_4=nn.ConvTranspose2d(ngf//2, ngf//2, 3, 1, 1)
        self.l4_batch_4=nn.BatchNorm2d(ngf//2)
        
        self.l4_5=nn.ConvTranspose2d(ngf//2, ngf//2, 3, 1, 1)
        self.l4_batch_5=nn.BatchNorm2d(ngf//2)
        
        self.l4_6=nn.ConvTranspose2d(ngf//2, ngf//2, 3, 1, 1)
        self.l4_batch_6=nn.BatchNorm2d(ngf//2)
        
        self.l4_up=nn.ConvTranspose2d(ngf//2, ngf//2, 4, 2, 1)
        
        #################################
        # 8 x 8
        #################################
        self.l8_1=nn.ConvTranspose2d(ngf//2, ngf//4, 3, 1, 1)
        
        self.l8_2=nn.ConvTranspose2d(ngf//4, ngf//4, 3, 1, 1)
        self.l8_batch_2=nn.BatchNorm2d(ngf//4)
        
        self.l8_3=nn.ConvTranspose2d(ngf//4, ngf//4, 3, 1, 1)
        self.l8_batch_3=nn.BatchNorm2d(ngf//4)
        
        self.l8_4=nn.ConvTranspose2d(ngf//4, ngf//4, 3, 1, 1)
        self.l8_batch_4=nn.BatchNorm2d(ngf//4)
        
        self.l8_5=nn.ConvTranspose2d(ngf//4, ngf//4, 3, 1, 1)
        self.l8_batch_5=nn.BatchNorm2d(ngf//4)
        
        self.l8_6=nn.ConvTranspose2d(ngf//4, ngf//4, 3, 1, 1)
        self.l8_batch_6=nn.BatchNorm2d(ngf//4)
        
        self.l8_up=nn.ConvTranspose2d(ngf//4, ngf//4, 4, 2, 1)
        
        #################################
        # 16 x 16
        #################################
        self.l16_1=nn.ConvTranspose2d(ngf//4, ngf//8, 3, 1, 1)
        
        self.l16_2=nn.ConvTranspose2d(ngf//8, ngf//8, 3, 1, 1)
        self.l16_batch_2=nn.BatchNorm2d(ngf//8)
        
        self.l16_3=nn.ConvTranspose2d(ngf//8, ngf//8, 3, 1, 1)
        self.l16_batch_3=nn.BatchNorm2d(ngf//8)
        
        self.l16_4=nn.ConvTranspose2d(ngf//8, ngf//8, 3, 1, 1)
        self.l16_batch_4=nn.BatchNorm2d(ngf//8)
        
        self.l16_5=nn.ConvTranspose2d(ngf//8, ngf//8, 3, 1, 1)
        self.l16_batch_5=nn.BatchNorm2d(ngf//8)
        
        self.l16_6=nn.ConvTranspose2d(ngf//8, ngf//8, 3, 1, 1)
        self.l16_batch_6=nn.BatchNorm2d(ngf//8)
        
        self.l16_up=nn.ConvTranspose2d(ngf//8, ngf//8, 4, 2, 1)
        
        #################################
        # 32 x 32
        #################################
        self.l32_1=nn.ConvTranspose2d(ngf//8, ngf//16, 3, 1, 1)
        
        self.l32_2=nn.ConvTranspose2d(ngf//16, ngf//16, 3, 1, 1)
        self.l32_batch_2=nn.BatchNorm2d(ngf//16)
        
        self.l32_3=nn.ConvTranspose2d(ngf//16, ngf//16, 3, 1, 1)
        self.l32_batch_3=nn.BatchNorm2d(ngf//16)
        
        self.l32_4=nn.ConvTranspose2d(ngf//16, ngf//16, 3, 1, 1)
        self.l32_batch_4=nn.BatchNorm2d(ngf//16)
        
        self.l32_5=nn.ConvTranspose2d(ngf//16, ngf//16, 3, 1, 1)
        self.l32_batch_5=nn.BatchNorm2d(ngf//16)
        
        self.l32_6=nn.ConvTranspose2d(ngf//16, ngf//16, 3, 1, 1)
        self.l32_batch_6=nn.BatchNorm2d(ngf//16)
        
        self.l32_up=nn.ConvTranspose2d(ngf//16, ngf//16, 4, 2, 1)
        
        #################################
        # 64 x 64
        #################################
        self.l64_1=nn.ConvTranspose2d(ngf//16, ngf//32, 3, 1, 1)
        
        self.l64_2=nn.ConvTranspose2d(ngf//32, ngf//32, 3, 1, 1)
        self.l64_batch_2=nn.BatchNorm2d(ngf//32)
        
        self.l64_3=nn.ConvTranspose2d(ngf//32, ngf//32, 3, 1, 1)
        self.l64_batch_3=nn.BatchNorm2d(ngf//32)
        
        self.l64_4=nn.ConvTranspose2d(ngf//32, ngf//32, 3, 1, 1)
        self.l64_batch_4=nn.BatchNorm2d(ngf//32)
        
        self.l64_5=nn.ConvTranspose2d(ngf//32, ngf//32, 3, 1, 1)
        self.l64_batch_5=nn.BatchNorm2d(ngf//32)
        
        self.l64_6=nn.ConvTranspose2d(ngf//32, ngf//32, 3, 1, 1)
        self.l64_batch_6=nn.BatchNorm2d(ngf//32)
        
        self.l64_final=nn.ConvTranspose2d(ngf//32, 4, 3, 1, 1)

        self.R=nn.ReLU()
    def forward(self, input):
        input=self.linear(input)
        
        x4_1=self.l4_1(self.l1_up(input[:,:,None,None]))
        
        x4_2=self.R(self.l4_batch_2(self.l4_2(x4_1)))
        x4_3=self.R(self.l4_batch_3(self.l4_3(x4_2)))
        x4_3=x4_1+x4_3
        x4_4=self.R(self.l4_batch_4(self.l4_4(x4_3)))
        x4_5=self.R(self.l4_batch_5(self.l4_5(x4_4)))
        x4_6=self.R(self.l4_batch_6(self.l4_6(x4_5)))
        x4_6=x4_4+x4_6
        
        x8_1=self.l8_1(self.l4_up(x4_6))
        
        x8_2=self.R(self.l8_batch_2(self.l8_2(x8_1)))
        x8_3=self.R(self.l8_batch_3(self.l8_3(x8_2)))
        x8_3=x8_1+x8_3
        x8_4=self.R(self.l8_batch_4(self.l8_4(x8_3)))
        x8_5=self.R(self.l8_batch_5(self.l8_5(x8_4)))
        x8_6=self.R(self.l8_batch_6(self.l8_6(x8_5)))
        x8_6=x8_4+x8_6
        
        x16_1=self.l16_1(self.l8_up(x8_6))
        
        x16_2=self.R(self.l16_batch_2(self.l16_2(x16_1)))
        x16_3=self.R(self.l16_batch_3(self.l16_3(x16_2)))
        x16_3=x16_1+x16_3
        x16_4=self.R(self.l16_batch_4(self.l16_4(x16_3)))
        x16_5=self.R(self.l16_batch_5(self.l16_5(x16_4)))
        x16_6=self.R(self.l16_batch_6(self.l16_6(x16_5)))
        x16_6=x16_4+x16_6
        
        x32_1=self.l32_1(self.l16_up(x16_6))
        
        x32_2=self.R(self.l32_batch_2(self.l32_2(x32_1)))
        x32_3=self.R(self.l32_batch_3(self.l32_3(x32_2)))
        x32_3=x32_1+x32_3
        x32_4=self.R(self.l32_batch_4(self.l32_4(x32_3)))
        x32_5=self.R(self.l32_batch_5(self.l32_5(x32_4)))
        x32_6=self.R(self.l32_batch_6(self.l32_6(x32_5)))
        x32_6=x32_4+x32_6
        
        x64_1=self.l64_1(self.l32_up(x32_6))
        
        x64_2=self.R(self.l64_batch_2(self.l64_2(x64_1)))
        x64_3=self.R(self.l64_batch_3(self.l64_3(x64_2)))
        x64_3=x64_1+x64_3
        x64_4=self.R(self.l64_batch_4(self.l64_4(x64_3)))
        x64_5=self.R(self.l64_batch_5(self.l64_5(x64_4)))
        x64_6=self.R(self.l64_batch_6(self.l64_6(x64_5)))
        x64_6=x64_4+x64_6
        
        return self.l64_final(x64_6)

nz=7
ngf=256
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = Generator()
model.to(device)
model.load_state_dict(torch.load('./model_1'))
model.eval()

E_min=5
E_max=10

x = loadmat('./phi_circle_6.mat')
phi_target1=x.get('phi')
E1=6

x = loadmat('./phi_star_9.mat')
phi_target2=x.get('phi')
E2=9

def f_and_grad(x):
    
    w1=np.zeros((1,4,64,64))
    w1[0,:,:,:]=phi_target1
    w1=w1.astype(np.float32)
    w1=torch.tensor(w1).to(device)
    
    X_input=(x+5)/25
    temp_x=np.zeros((1, nz))
    temp_x[0,0:nz-1]=X_input
    temp_x[0,nz-1]=(E1-E_min)/(E_max-E_min)
    # print(temp_x)
    temp_x=temp_x.astype(np.float32)
    temp_x0=torch.tensor(temp_x,requires_grad=True)
    temp_x=temp_x0.to(device)
    yhat=model(temp_x)
    
    s1=torch.sum(torch.abs(w1-yhat)**2)
    s1.backward()
    g1=temp_x0.grad
    g1=g1.cpu().detach().numpy()
    s1=s1.cpu().detach().numpy()
    g1=g1[0,0:nz-1]
    
    w2=np.zeros((1,4,64,64))
    w2[0,:,:,:]=phi_target2
    w2=w2.astype(np.float32)
    w2=torch.tensor(w2).to(device)
    
    X_input=(x+5)/25
    temp_x=np.zeros((1, nz))
    temp_x[0,0:nz-1]=X_input
    temp_x[0,nz-1]=(E2-E_min)/(E_max-E_min)
    # print(temp_x)
    temp_x=temp_x.astype(np.float32)
    temp_x0=torch.tensor(temp_x,requires_grad=True)
    temp_x=temp_x0.to(device)
    yhat=model(temp_x)
    
    s2=torch.sum(torch.abs(w2-yhat)**2)
    s2.backward()
    g2=temp_x0.grad
    g2=g2.cpu().detach().numpy()
    s2=s2.cpu().detach().numpy()
    g2=g2[0,0:nz-1]
    # print(s,g)
    return s1+s2,g1+g2

res=minimize(f_and_grad, np.random.rand(6)*25-5, jac=True)
print(res.x)
res_s,res_g=f_and_grad(res.x)
print(res_s)

